// import { parseLyric } from "./parse_lyric.js"

import parseLyric from "./parse_lyric.js"

console.log(parseLyric())
