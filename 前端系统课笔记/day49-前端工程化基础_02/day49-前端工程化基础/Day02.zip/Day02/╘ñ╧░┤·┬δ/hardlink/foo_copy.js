const name = "foo"
console.log(name)

function foo() {
  console.log("foo")
}

