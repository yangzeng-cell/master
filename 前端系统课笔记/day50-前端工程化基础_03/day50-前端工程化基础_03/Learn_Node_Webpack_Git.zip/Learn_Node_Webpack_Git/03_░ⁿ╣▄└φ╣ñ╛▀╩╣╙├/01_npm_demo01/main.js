const dayjs = require("dayjs")

console.log(dayjs())

