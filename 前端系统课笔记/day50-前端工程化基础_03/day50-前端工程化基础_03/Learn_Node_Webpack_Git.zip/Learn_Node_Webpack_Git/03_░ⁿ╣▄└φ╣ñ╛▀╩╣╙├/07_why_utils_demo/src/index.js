import { formatCount, formatDate, sum, mul, sub } from "why_utils_00"


console.log(formatCount())
console.log(formatDate())

console.log(sum(20, 30))
console.log(mul(111, 222))

console.log(mul(100, 200))

console.log(sub(100, 20))

