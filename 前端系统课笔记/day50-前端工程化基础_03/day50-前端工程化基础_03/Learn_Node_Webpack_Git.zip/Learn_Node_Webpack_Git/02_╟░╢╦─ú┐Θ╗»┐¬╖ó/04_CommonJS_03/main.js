// 1.根据路径导入自己编写模块
// const utils = require("./utils")
// console.log(utils.formatDate())

// const foo = require("./foo")


// 2.导入node提供给内置模块
// const path = require("path")
// const http = require("http")
// console.log(path, http)


// 3.情况三: 名称不是路径, 也不是一个内置模块
// const why = require("why")
// console.log(why)

// const axios = require("axios")
// console.log(axios)

console.log(this)
