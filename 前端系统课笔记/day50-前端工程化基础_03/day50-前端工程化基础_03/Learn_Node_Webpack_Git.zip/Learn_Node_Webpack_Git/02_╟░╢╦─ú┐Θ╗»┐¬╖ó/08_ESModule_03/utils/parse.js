export function parseLyric(lyricString) {
  return ["歌词"]
}
