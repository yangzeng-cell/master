module.exports = {
  plugins: [
    // "autoprefixer"
    "postcss-preset-env"
  ]
}
