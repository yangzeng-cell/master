export function sum(num1, num2) {
  return num1 + num2
}


console.log(sum(1231111, 321123))
console.log("------++111222333")

