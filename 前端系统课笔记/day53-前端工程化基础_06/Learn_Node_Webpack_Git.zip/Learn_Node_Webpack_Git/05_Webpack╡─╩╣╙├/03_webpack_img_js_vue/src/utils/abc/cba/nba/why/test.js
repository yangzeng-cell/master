import { sum } from "utils/math.js"

console.log(sum(20, 30))

