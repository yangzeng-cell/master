export function formatCount() {
  return "200万"
}

export function formatDate() {
  return "2022-11-11"
}
