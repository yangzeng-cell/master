const message = "Hello World"
console.log(message)


function foo(arg) {
  console.log(arg.length)
}

foo(message)
foo("coderwhy")

function sum(num1, num2) {
  return num1 + num2
}

sum(20, 30)
sum(111, 222)



