import styled from 'styled-components';

export const HYArtistWrapper = styled.div`
  .content {
    display: flex;
    background-color: #fff;
  }
`