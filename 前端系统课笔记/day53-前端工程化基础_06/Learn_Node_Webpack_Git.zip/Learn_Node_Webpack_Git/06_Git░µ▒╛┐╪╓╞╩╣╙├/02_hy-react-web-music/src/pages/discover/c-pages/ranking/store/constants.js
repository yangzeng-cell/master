export const CHANGE_TOP_LIST = "ranking/CHANGE_TOP_LIST";
export const CHANGE_CURRENT_INDEX = "rangking/CHANGE_CURRENT_INDEX";
export const CHANGE_PLAY_LIST = "ranking/CHANGE_PLAY_LIST";
