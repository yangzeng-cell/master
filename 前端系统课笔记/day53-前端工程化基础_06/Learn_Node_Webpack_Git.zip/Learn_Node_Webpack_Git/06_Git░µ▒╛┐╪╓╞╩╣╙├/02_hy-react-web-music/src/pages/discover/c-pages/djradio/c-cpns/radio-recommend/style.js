import styled from 'styled-components';

export const RecommendWrapper = styled.div`
  .radio-list {
    margin: 20px 0 40px;
    display: flex;
    justify-content: space-between;
  }
`