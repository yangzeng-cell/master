console.log("abc")
console.log("------")

function foo() {
  console.log("foo function")
}

foo()

console.log("1111111")

console.log("2222222")

console.log("3333333")
