// 定义了全局变量
var $ = function () {
  return 'hy-utils'
}
