# Day01 作业布置

## 一. 完成课堂所有的代码





## 二.jQuery函数和jQuey对象分别是什么？





## 三.jQuery对象和DOM Element有什么区别？





## 四.jQuery中常用的过滤器有哪些（Filtering）





















