// 定义了全局变量
var $ = function () {
  return 'hy-utils'
}

var jQuery = function () {
  return 'hy-utils2'
}


// var noConflict = function() {

// }