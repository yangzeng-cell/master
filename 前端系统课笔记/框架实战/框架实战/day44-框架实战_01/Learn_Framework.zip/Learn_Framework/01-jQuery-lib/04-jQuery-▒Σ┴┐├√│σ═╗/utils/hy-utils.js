var $ = '我是hy-utils'
var jQuery = '我是hy-utils jQuery'

