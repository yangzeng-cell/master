;(function(g) {

  function Lodash() {

  }

  // 添加类方法
  Lodash.VERSION = '1.0.0'
  Lodash.join = function(arr, separater) {
    // todo ......
    return arr.join(separater)
  }

  // ....
  Lodash.debounce = function() {}
  Lodash.throttle = function() {}
  Lodash.random = function() {}
  Lodash.endsWith = function() {}
  Lodash.clone = function() {}
  Lodash.cloneDeep = function() {}
  Lodash.merge = function() {}

  g._ = Lodash
})(window)