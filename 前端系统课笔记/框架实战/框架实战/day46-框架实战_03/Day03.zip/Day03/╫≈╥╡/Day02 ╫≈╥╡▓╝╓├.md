# Day03 作业布置

## 一. 完成课堂所有的代码



## 二.列出AJAX常用的配置参数(Parameters)



## 三.用jQuery的AJAX编写GET和POST请求



## 四.列出Lodash其它常用的函数



























