const HYConfig = {
  BASE_URL: 'http://123.207.32.32:9060/beike/api'
}

const HYAPI = {
  HOT_RECOMMEND: '/site/rent',
  HOME_SEARCH: '/sug/headerSearch',

  HOME_PAGE: '/homePageInfo'
}