const message = "Hello World"
console.log(message)

