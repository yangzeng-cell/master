module.exports = {
  plugins: [
    "postcss-preset-env"
  ]
}

// px -> rem/vw
