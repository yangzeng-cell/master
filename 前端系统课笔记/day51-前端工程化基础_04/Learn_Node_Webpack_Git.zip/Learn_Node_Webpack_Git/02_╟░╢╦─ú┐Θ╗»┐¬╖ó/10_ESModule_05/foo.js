export const name = "foo"
export const age = 18

export function sayHello() {
  console.log("sayHello")
}

console.log(import.meta)

