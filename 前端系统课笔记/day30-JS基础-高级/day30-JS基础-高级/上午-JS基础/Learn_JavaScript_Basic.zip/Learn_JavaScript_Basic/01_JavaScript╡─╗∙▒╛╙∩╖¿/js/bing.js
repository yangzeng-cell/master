// 获取元素
var bingAEl = document.querySelector(".bing")

// 监听元素的点击
bingAEl.onclick = function() {
  alert("bing一下")
}