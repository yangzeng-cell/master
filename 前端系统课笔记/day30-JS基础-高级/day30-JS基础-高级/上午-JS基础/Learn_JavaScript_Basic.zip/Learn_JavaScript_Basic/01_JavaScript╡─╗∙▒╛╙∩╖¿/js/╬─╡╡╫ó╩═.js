/**
 * 和某人打招呼
 * @param {string} name 姓名
 * @param {number} age 年龄
 */
function sayHello(name, age) {

}


sayHello("why", 18)
