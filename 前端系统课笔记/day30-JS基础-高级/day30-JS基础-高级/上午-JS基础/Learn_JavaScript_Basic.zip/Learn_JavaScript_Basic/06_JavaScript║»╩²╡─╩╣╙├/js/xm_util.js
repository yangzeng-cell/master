(function() {
  console.log(xmModule.message) 
})()

