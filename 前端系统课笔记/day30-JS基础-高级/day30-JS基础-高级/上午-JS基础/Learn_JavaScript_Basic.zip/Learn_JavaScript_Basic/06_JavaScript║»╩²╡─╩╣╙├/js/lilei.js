(function(){
  var message = "Hello LiLei"
  console.log(message)
})()
